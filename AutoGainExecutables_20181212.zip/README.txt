param.txt setting
-------------------
1440   // First line = initial period without learning in minutes. e.g., 1440 = 60 * 24 = 1 day
0.1    // gain change rate